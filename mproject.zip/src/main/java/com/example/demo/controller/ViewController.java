package com.example.demo.controller;

import org.springframework.security.access.prepost.*;
import org.springframework.stereotype.*;
import org.springframework.web.bind.annotation.*;

@Controller
public class ViewController {
	@GetMapping({"/", "/board/list"})
	public String list() {
		return "/board/list";
	}
	
	@GetMapping("/board/read")
	public void read() {
	}
	
	@PreAuthorize("isAuthenticated()")
	@GetMapping("/board/write")
	public void write() {
	}
	
	@PreAuthorize("isAnonymoust()")
	@GetMapping("/member/join")
	public void join() {
	}
	
	@PreAuthorize("isAnonymoust()")
	@GetMapping("/member/find_id")
	public void findId() {
	}
	
	@PreAuthorize("isAnonymoust()")
	@GetMapping("/member/find_password")
	public void resetPassword() {
	}
	
	@PreAuthorize("isAuthenticated()")
	@GetMapping("/member/read")
	public void myInfo() {
	}
}
