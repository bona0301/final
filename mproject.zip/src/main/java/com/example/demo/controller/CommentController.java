package com.example.demo.controller;

import java.security.*;
import java.util.*;

import org.springframework.beans.factory.annotation.*;
import org.springframework.http.*;
import org.springframework.security.access.prepost.*;
import org.springframework.validation.*;
import org.springframework.validation.annotation.*;
import org.springframework.web.bind.annotation.*;

import com.example.demo.dto.*;
import com.example.demo.service.*;

@Validated
@RestController
public class CommentController {
	@Autowired
	private CommentService service;
	
	@PreAuthorize("isAuthenticated()")
	@PostMapping(value="/comments/new", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<CommentDto.Read>> write(CommentDto.Write dto, BindingResult bindingResult, Principal principal) {
		return ResponseEntity.ok(service.write(dto, principal.getName()));
	}
	
	@PreAuthorize("isAuthenticated()")
	@DeleteMapping(value="/comments", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<CommentDto.Read>> delete(CommentDto.Delete dto, BindingResult bindingResult, Principal principal) {
		return ResponseEntity.ok(service.delete(dto, principal.getName()));
	}
}
