package com.example.demo.controller;

import java.net.*;
import java.security.*;

import javax.validation.*;
import javax.validation.constraints.*;

import org.springframework.beans.factory.annotation.*;
import org.springframework.http.*;
import org.springframework.security.access.prepost.*;
import org.springframework.validation.*;
import org.springframework.validation.annotation.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.*;

import com.example.demo.dto.*;
import com.example.demo.entity.*;
import com.example.demo.service.*;

@Validated
@RestController
public class BoardController {
	@Autowired
	private BoardService service;

	@PreAuthorize("isAuthenticated()")
	@PostMapping(value="/board/new", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Board> write(@Valid BoardDto.Write dto, BindingResult bindingResult, Principal principal) {
		Board board = service.write(dto, principal.getName());
		URI uri = UriComponentsBuilder.newInstance().path("/board/read").queryParam("bno", board.getBno()).build().toUri();
		return ResponseEntity.created(uri).body(board);
	}
	
	@GetMapping(value="/board/all", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<BoardDto.Page> list(@RequestParam(defaultValue="1") Integer pageno) {
		System.out.println(service.list(pageno));
		return ResponseEntity.ok(service.list(pageno));
	}
	
	@GetMapping(value="/board", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<BoardDto.Read> read(@NotNull Integer bno, Principal principal) {
		String loginId = principal==null? null : principal.getName();
		return ResponseEntity.ok(service.read(bno, loginId));
	}
	
	@PreAuthorize(value="isAuthenticated()")
	@PutMapping(value="/board", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Board> update(@Valid BoardDto.Update dto, BindingResult bindingResult, Principal principal) {
		service.update(dto, principal.getName());
		return ResponseEntity.ok(null);
	}
	
	@PreAuthorize(value="isAuthenticated()")	
	@DeleteMapping(value="/board")
	public ResponseEntity<Void> delete(@NotNull Integer bno, Principal principal) {
		service.delete(bno, principal.getName());
		return ResponseEntity.ok(null);
	}
}
