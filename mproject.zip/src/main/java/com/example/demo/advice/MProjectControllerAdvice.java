package com.example.demo.advice;

import java.util.*;

import javax.validation.*;

import org.springframework.http.*;
import org.springframework.web.bind.*;
import org.springframework.web.bind.annotation.*;

import com.example.demo.exception.*;

@RestControllerAdvice
public class MProjectControllerAdvice {
	@ExceptionHandler(ConstraintViolationException.class)
	public ResponseEntity<Collection<String>> validFailHandler(ConstraintViolationException e) {
		Collection<String> messages = new ArrayList<>();
		String[] ms = e.getMessage().split(", ");
		for(String s:ms) {
			int start = s.lastIndexOf(".")+1;
			int end = s.lastIndexOf(":");
			String fieldName = s.substring(start, end);
			String exceptionMessage = s.substring(end+2);
			messages.add(fieldName + " " + exceptionMessage); 
		}
		return ResponseEntity.status(HttpStatus.CONFLICT).body(messages);
	}
	
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<String> validFailHandler(MethodArgumentNotValidException e) {
		System.out.println(e.getBindingResult().getAllErrors().get(0));
		return ResponseEntity.status(HttpStatus.CONFLICT).body(e.getBindingResult().getAllErrors().get(0).getDefaultMessage());
	}
	
	@ExceptionHandler(BoardNotFoundException.class)
	public ResponseEntity<String> boardNotFoundExceptionHandler() {
		return ResponseEntity.status(HttpStatus.CONFLICT).body("선택하신 게시물이 존재하지 않습니다");
	}
	
	@ExceptionHandler(CommentNotFoundException.class)
	public ResponseEntity<String> commentNotFoundExceptionHandler() {
		return ResponseEntity.status(HttpStatus.CONFLICT).body("댓글을 삭제하지 못했습니다");
	}
	
	@ExceptionHandler(JobFailException.class)
	public ResponseEntity<String> jobFailExceptionHandler(JobFailException e) {
		return ResponseEntity.status(HttpStatus.CONFLICT).body(e.getMessage());
	}
}
