package com.example.demo.service;

import java.util.*;

import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import org.springframework.transaction.annotation.*;

import com.example.demo.dao.*;
import com.example.demo.dto.*;
import com.example.demo.entity.*;
import com.example.demo.exception.*;

@Service
public class CommentService {
	@Autowired
	private CommentDao commentDao;
	@Autowired
	private BoardDao boardDao;
	
	@Transactional
	public List<CommentDto.Read> write(CommentDto.Write dto, String loginId) {
		BoardDto.Read read = boardDao.findById(dto.getBno()).orElseThrow(BoardNotFoundException::new);
		commentDao.save(dto.toEntity().registerWriter(loginId));
		Integer commentCnt = read.getCommentCnt()+1;
		boardDao.update(Board.builder().bno(dto.getBno()).commentCnt(commentCnt).build());
		return commentDao.findByBno(dto.getBno());
	}

	@Transactional
	public List<CommentDto.Read> delete(CommentDto.Delete dto, String loginId) {
		BoardDto.Read read = boardDao.findById(dto.getBno()).orElseThrow(BoardNotFoundException::new);
		String writer = commentDao.findWriterById(dto.getCno()).orElseThrow(CommentNotFoundException::new);
		if(!writer.equals(loginId))
			throw new JobFailException("댓글을 삭제하지 못했습니다");
		Integer commentCnt = read.getCommentCnt()-1;
		boardDao.update(Board.builder().bno(dto.getBno()).commentCnt(commentCnt).build());
		commentDao.deleteById(dto.getCno());
		return commentDao.findByBno(dto.getBno());
	}
}
