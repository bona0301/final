package com.example.demo.service;

import java.util.*;

import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import org.springframework.transaction.annotation.*;

import com.example.demo.dao.*;
import com.example.demo.dto.*;
import com.example.demo.entity.*;
import com.example.demo.exception.*;

@Service
public class BoardService {
	@Autowired
	private BoardDao boardDao;
	@Autowired
	private CommentDao commentDao;
	@Value("10")
	private Integer PAGESIZE;
	
	public Board write(BoardDto.Write dto, String loginId) {
		Board board = dto.toEntity().registerWriter(loginId);
		boardDao.save(board);
		return board;
	}

	public BoardDto.Page list(Integer pageno) {
		Integer count = boardDao.count(null);
		Integer start = (pageno-1)*PAGESIZE + 1;
		Integer end = start + PAGESIZE - 1;
		if(end>count)
			end=count;
		List<BoardDto.ForList> boardList = boardDao.findAll(null, start, end);
		return new BoardDto.Page(pageno, PAGESIZE, count, boardList);
	}

	@Transactional
	public BoardDto.Read read(Integer bno, String loginId) {
		BoardDto.Read dto = boardDao.findById(bno).orElseThrow(BoardNotFoundException::new);
		if(dto.getWriter().equals(loginId)==false)
			boardDao.update(Board.builder().bno(bno).readCnt(1).build());
		if(dto.getCommentCnt()>0)
			dto.setComments(commentDao.findByBno(bno));
		return dto;
	}

	
	public Integer update(BoardDto.Update dto, String loginId) {
		String writer = boardDao.findWriterById(dto.getBno()).orElseThrow(BoardNotFoundException::new);
		if(writer.equals(loginId)==false)
			throw new JobFailException("글을 변경하지 못했습니다");
		Board board = dto.toEntity();
		return boardDao.update(board);
	}

	@Transactional
	public Integer delete(Integer bno, String loginId) {
		String writer = boardDao.findWriterById(bno).orElseThrow(BoardNotFoundException::new);
		System.out.println(writer);
		System.out.println(loginId);
		if(writer.equals(loginId)==false)
			throw new JobFailException("글을 삭제하지 못했습니다");
		commentDao.deleteByBno(bno);
		return boardDao.deleteById(bno);
	}
}
